data:extend({
	{
		type = "int-setting",
		name = "flan-slots",
		default_value = 6,
		minimum_value = 3,
		maximum_value = 10,
		setting_type = "startup"
	}
})