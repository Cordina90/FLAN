data:extend({
  {
    type = "item",
    name = "flantenna",
    icon = "__Factorio-LAN__/graphics/icons/flantenna.png",
    icon_size = 32,
    subgroup = "circuit-network",
    place_result="flantenna",
    order = "c[other]-b[flantenna]",
    stack_size= 50,
  },
  {
    type = "item",
    name = "flantenna2",
    icon = "__Factorio-LAN__/graphics/icons/flantenna.png",
    icon_size = 32,
    subgroup = "circuit-network",
    place_result="flantenna2",
    order = "c[other]-b[flantenna]",
    stack_size= 50,
  }

})