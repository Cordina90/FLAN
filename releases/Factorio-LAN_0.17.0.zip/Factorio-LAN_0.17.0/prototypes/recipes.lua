data:extend({
  {
    type = "recipe",
    name = "flantenna",
    enabled = false,
    ingredients =
    {
      {"steel-plate", 5},
      {"electronic-circuit", 5},
      {"advanced-circuit", 10},
      {"copper-cable", 10}
    },
    result = "flantenna"
  }
})